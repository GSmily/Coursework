package com.example.gsmily.motounitedcatalog;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Created by GSmily on 12/14/2017.
 */

public class OpenMapActivity extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap mMap;
    private static final int ERROR_DIALOG_REQUEST = 9001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(servicesOK()){
            setContentView(R.layout.activity_map);
         SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
         mapFragment.getMapAsync(this);
        } else {
            setContentView(R.layout.activity_main);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng st_george = new LatLng(-34, 151);
        googleMap.addMarker(new MarkerOptions().position(st_george).title("Moto United in St. George"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(st_george));
    }

    public boolean servicesOK() {
        GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
        int result = googleAPI.isGooglePlayServicesAvailable(this);

        if(result == ConnectionResult.SUCCESS) {
            return true;
        } else if (googleAPI.isUserResolvableError(result)) {
            googleAPI.getErrorDialog(this, result, ERROR_DIALOG_REQUEST).show();
        } else {
            Toast.makeText(this, "Can't connect to mapping service", Toast.LENGTH_SHORT).show();
        }
        return false;
    }

}
