package com.example.gsmily.motounitedcatalog.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.gsmily.motounitedcatalog.model.DataItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by GSmily on 12/13/2017.
 */

public class DataSource {

    private Context mContext;
    private SQLiteDatabase mdatabase;
    private SQLiteOpenHelper mdbHelper;

    public DataSource(Context Context) {
        this.mContext = Context;
        mdbHelper = new DBHelper(mContext);
        mdatabase = mdbHelper.getWritableDatabase();
    }

    public void open(){
        mdatabase = mdbHelper.getWritableDatabase();
    }
    public void close(){
        mdbHelper.close();
    }

    public DataItem createItem(DataItem item)
    {
        ContentValues values = item.toValues();
        mdatabase.insert(ItemTable.TABLE_ITEMS,null,values);
        return item;
    }

    public long getDataItemsCount()
    {
        return DatabaseUtils.queryNumEntries(mdatabase,ItemTable.TABLE_ITEMS);
    }

    public void writeDatabase(List<DataItem> dataItemList)
    {
        long numItems = getDataItemsCount();
        if (numItems == 0) {
            for (DataItem item : dataItemList) {
                try {
                    createItem(item);
                } catch (SQLiteException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public List<DataItem> getAllItems(String category) {
        List<DataItem> dataItems = new ArrayList<>();

        Cursor cursor = null;
        String [] categories = {category};
        if (category == null) {
            cursor = mdatabase.query(ItemTable.TABLE_ITEMS, ItemTable.ALL_COLUMNS,
                    null, null, null, null,
                    ItemTable.COLUMN_NAME + " DESC");
        }
        else {
            cursor = mdatabase.query(ItemTable.TABLE_ITEMS, ItemTable.ALL_COLUMNS,
                    ItemTable.COLUMN_CATEGORY + "=?", categories, null, null,
                    ItemTable.COLUMN_NAME);
        }
        //select ALL_COLUMNS from TABLE_ITEMS ORDERBY COLUMN_NAME DESC

        while (cursor.moveToNext()) {
            DataItem dataItem = new DataItem();
            dataItem.setItemId(cursor.getString(
                    cursor.getColumnIndex(ItemTable.COLUMN_ID)));
            dataItem.setItemName(cursor.getString(
                    cursor.getColumnIndex(ItemTable.COLUMN_NAME)));
            dataItem.setDescription(cursor.getString(
                    cursor.getColumnIndex(ItemTable.COLUMN_DESCRIPTION)));
            dataItem.setCategory(cursor.getString(
                    cursor.getColumnIndex(ItemTable.COLUMN_CATEGORY)));
            dataItem.setSortPosition(cursor.getInt(
                    cursor.getColumnIndex(ItemTable.COLUMN_ID)));
            dataItem.setPrice(cursor.getDouble(
                    cursor.getColumnIndex(ItemTable.COLUMN_PRICE)));
            dataItem.setImage(cursor.getString(
                    cursor.getColumnIndex(ItemTable.COLUMN_IMAGE)));
            dataItems.add(dataItem);
        }
        return dataItems;
    }
}

