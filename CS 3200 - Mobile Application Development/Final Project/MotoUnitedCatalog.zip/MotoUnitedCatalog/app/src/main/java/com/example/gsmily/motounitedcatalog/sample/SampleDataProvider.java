package com.example.gsmily.motounitedcatalog.sample;

/**
 * Created by GSmily on 12/13/2017.
 */

import com.example.gsmily.motounitedcatalog.model.DataItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SampleDataProvider {
    public static List<DataItem> dataItemList;
    public static Map<String, DataItem> dataItemMap;

    static {
        dataItemList = new ArrayList<>();
        dataItemMap = new HashMap<>();

        addItem(new DataItem(null, "2017 HONDA FOURTRAX FOREMAN 4x4", "ATVs",
                "Some jobs, it doesn't matter if the work gets done today or tomorrow. Or if it’s raining or cold or blazing hot outside. Others, need to get done now, and done right the first time. Especially if you have people counting on you, or your paycheck riding on the line. That’s when you need the best tools—and the best help—that you can find. That’s when you need a Honda FourTrax Foreman.",
                1, 7299, "atv_honda_fourtrax.jpg"));

        addItem(new DataItem(null, "2017 HONDA FOURTRAX RANCHER", "ATVs",
                "Any mechanic, woodworker, tradesman or craftsman knows that the right tool makes the job a whole lot easier. And having the right tool means having a choice. We’ve all seen someone try to drive a screw with a butter knife, or pound a nail with a shoe heel. The results are never pretty. Honda’s FourTrax Rancher line are premium tools for the jobs you need to do, whether that’s on the farm, the jobsite, hunting, fishing, exploring... or on the ranch. It’s easy for you to choose the right mix of features—just like reaching for that right tool. Every Rancher starts with the same proven Honda engine, the heart of any ATV. A 420 cc liquid-cooled single-cylinder design with fuel injection, it’s engineered for the kind of wide, low-revving power an ATV rider wants. And it offers something no other ATV can: Honda’s legendary reliability and efficiency.",
                2, 5349, "atv_honda_fourtrax_rancher.jpg"));

        addItem(new DataItem(null, "2017 HONDA TRX250X", "ATVs",
                "Maybe specialization is fine if you’re talking about insects. But in the world of a great all-around sport ATV, versatility is the key to having a good time. You want a machine that can fit a wide range of riders, abilities and terrains. And that ATV is the Honda TRX250X.",
                3, 4749, "atv_honda_trx250x.jpg"));

        addItem(new DataItem(null, "2017 HONDA FOURTRAX RECON", "ATVs",
                "There’s an old saying: It’s not the size of the dog in the fight; it’s the size of the fight in the dog. And that’s certainly true when it comes to the world of all-terrain vehicles. Bigger isn’t always better—like on a tight trail, when it’s time to load and unload, or when it’s time to open up your wallet.",
                4, 4099, "atv_honda_fourtrax_recon.jpg"));

        addItem(new DataItem(null, "2018 SUZUKI KINGQUAD 500AXI", "ATVs",
                "In 1983, Suzuki introduced the world's first 4-wheel ATV. Today, Suzuki ATVs are everywhere. From the most remote areas to the most everyday tasks, you'll find the KingQuad powering a rider onward. Across the board, our KingQuad lineup is a dominating group of ATVs.",
                5, 7399, "atv_suzuki_kingquad_500axi.jpg"));

        addItem(new DataItem(null, "2018 SUZUKI QUADSPORT Z50", "ATVs",
                "The 2018 QuadSport Z50 is designed for adult-supervised riders age 6 and older and includes many features that make learning to ride a safe and fun experience. With an emphasis on safety and adult control, this Quad features a throttle limiter to control engine output, a tether switch to remotely shut off the ignition, and a keyed main switch that prevents unauthorized use. Adjustable hand controls, an automatic transmission, full floorboards, and a low seat height make sure that beginning riders will enjoy active convenience and control. To sum it up, the QuadSport Z50 is packed with quality, safety and style making it the perfect choice for younger adventurers!",
                6, 2049, "atv_suzuki_quadsport_Z50.jpg"));

        addItem(new DataItem(null, "2018 YAMAHA KODIAK 700 EPS", "ATVs",
                "Featuring On-Command 4WD with diff-lock, the Kodiak 700 EPS is ready to conquer tough work and trails with superior comfort and confidence.",
                7, 8499, "atv_yamaha_kodiak_700.jpg"));

        addItem(new DataItem(null, "2018 YAMAHA RAPTOR 700", "ATVs",
                "The Raptor 700 provides superior big-bore pure sport ATV performance in the ultimate affordable package.",
                8, 7999, "atv_yamaha_raptor_700.jpg"));

        addItem(new DataItem(null, "2017 HONDA PIONEER 1000", "SXS",
                "When it comes to finding new, innovative ways to solve problems, Honda has always risen to the challenge. Take our family of Pioneer 1000s. These great side-by-sides got it right the first time in terms of comfort, handling, hauling, and user-friendly features, but we’ve taken the opportunity to make them even better this year.",
                1, 14199, "sxs_honda_pioneer_1000.jpg"));

        addItem(new DataItem(null, "2017 HONDA PIONEER 700", "SXS",
                "Everybody’s looking for comfort. Everybody’s looking for value. Everybody’s looking for features. With a Honda Pioneer 700 and 700-4, you get it all, along with something no other brand can offer: Honda quality.",
                2, 10499, "sxs_honda_pioneer_700.jpg"));

        addItem(new DataItem(null, "2017 HONDA PIONEER 500", "SXS",
                "Choosing the right tool is the job half done. And it can make whatever you’re trying to do a lot more fun. For thousands of side-by-side owners, the right tool for the job is a Honda Pioneer 500. It’s big enough to seat two easily, but at just 50 inches wide, it can fit where bigger side-by-sides can’t, letting you explore trails with width restrictions.",
                3, 8999, "sxs_honda_pioneer_500.jpg"));

        addItem(new DataItem(null, "2006 SUZUKI Q.U.V.", "SXS",
                "Here's a flashy new utility vehicle that's as tough as it is hard-working. Introducing the new Suzuki Q.U.V 620 Automatic 4x4. The four-wheel drive Q.U.V. is engineered for rugged reliability, it's loaded with features that give it terrific off-road capabilities and it offers eye-catching pickup-truck styling. What's more, the Q.U.V. has advanced suspension systems to soak up rough terrain and provide you with all-day riding comfort.",
                4, 10, "sxs_suzuki_quv.jpg"));

        addItem(new DataItem(null, "2017 YAMAHA YXZ1000R", "SXS",
                "The YXZ1000R is in a class of its own with a sport-tuned 3-cylinder engine and industry first 5-speed sequential shift manual transmission.",
                5, 19999, "sxs_yamaha_yxz1000r.jpg"));

        addItem(new DataItem(null, "2017 YAMAHA VIKING VI EPS RANCH EDITION", "SXS",
                "The Viking VI EPS Ranch Edition sets the standard in comfort and convenience with true six-passenger luxury in a quieter and smoother riding machine.",
                6, 15599, "sxs_yamaha_viking_vi_ranch.jpg"));

        addItem(new DataItem(null, "2017 YAMAHA VIKING EPS", "SXS",
                "With true three-person seating, the enhanced Viking sets a new standard in comfort and convenience with a smooth, quiet and supremely capable ride.",
                7, 12999, "sxs_yamaha_viking_eps.jpg"));

        addItem(new DataItem(null, "2017 YAMAHA WOLVERINE", "SXS",
                "The Wolverine eagerly traverses tough, rugged terrain with superior confidence, comfort and reliability.",
                8, 10999, "sxs_yamaha_wolverine.jpg"));

        addItem(new DataItem(null, "2017 HONDA CRF450X", "Motorcycles",
                "It’s a dream everyone had, but nobody could deliver on—until Honda invented the CRF450X. The light weight and power of a motocross bike, available to trail riders, Baja demons, and cross-country racers everywhere. But actually the CRF450X is a whole lot better than just an MX bike off the track. It gets a ton of specialized touches and refinements that hone it for the trail.",
                1, 8699, "cycle_honda_crf450x.jpg"));

        addItem(new DataItem(null, "2017 HONDA CBR500R", "Motorcycles",
                "If you’re looking for a streetbike that is the perfect combination of size, performance, versatility and price, Honda’s CBR500R is exactly where you want to be. It’s the perfect companion for a spirited trip down a winding canyon road. Discover what a great daily-riding bike it is too: commuting, errand running, weekend pleasure trips. Looking for a first bike that you won’t outgrow in a year? A 500 twin is about the best choice you can make there. Generations of riders have known it, and the CBR500R is the newest incarnation.",
                2, 6599, "cycle_honda_cbr500r.jpg"));

        addItem(new DataItem(null, "2017 HONDA REBEL 500", "Motorcycles",
                "The Rebel 500 is a true triple threat: part impressive performance, part minimalist good looks and completely fun to ride. The first thing you’ll notice is its subtle, blacked-out looks. From the compact frame to its low-slung seat, it’s just cool. Once you get on, you’ll know immediately that this bike was meant to be ridden, thanks to an impressive lean angle, and a 471cc parallel-twin engine tuned for middle and upper-rpms.",
                3, 5999, "cycle_honda_rebel_500.jpg"));

        addItem(new DataItem(null, "2017 HONDA GROM", "Motorcycles",
                "f you—and about three-quarters of the planet—thought the Honda Grom was cool before, check out the 2017 version! The first thing you’ll notice is the new, aggressive bodywork and rad new colors. Then pay some attention to the new headlight—its LED design not only looks fresh, but it works great too. There’s a new two-tier seat, a more defined tail section, and a new low-mount muffler design.",
                4, 3299, "cycle_honda_grom.jpg"));

        addItem(new DataItem(null, "2018 SUZUKI GSX-R1000", "Motorcycles",
                "It has been three decades, with more than a million editions sold, since the GSX-R line was born. And a decade and a half has elapsed since the first GSX-R1000 transformed the open sportbike class forever. Built to Own the Racetrack, the GSX-R1000 captured the MotoAmerica Superbike Championship in its debut year asserting its claim as The King of Sportbikes. This motorcycle’s chassis forms the lightest, the most compact, the most aerodynamic and the best-handling GSX-R1000 ever. ",
                5, 14699, "cycle_suzuki_gsxr1000.jpg"));

        addItem(new DataItem(null, "2018 SUZUKI BOULEVARD C90 B.O.S.S.", "Motorcycles",
                "Performance never looked so good. The Suzuki Boulevard C90 B.O.S.S. rewards you with a striking combination of blacked-out styling and heart-pounding performance, thanks to its 90-cubic-inch V-twin engine. Along with aggressive styling and stunning performance, it features a spacious riding position and large floorboards for comfortable cruising on the highway, matched by precise agile handling provided by its rigid chassis and advanced suspension.",
                6, 12449, "cycle_suzuki_boulevard_c90.jpg"));

        addItem(new DataItem(null, "2018 SUZUKI RMX450Z", "Motorcycles",
                "Powerful, torquey fuel-injected 449 cc engine. Slim, aggressively styled chassis and bodywork. Electric starter. Full-function, two-mode instrument cluster. Enduro lighting. Additional chassis protection. Sharing core technologies with Suzuki’s Championship-winning open-class RM-Z450, the RMX450Z rewrites the rules for serious trail riders.",
                7, 8999, "cycle_suzuki_rmx450z.jpg"));

        addItem(new DataItem(null, "2018 YAMAHA YZF-R1", "Motorcycles",
                "The thrilling R1 blurs the line between daily rides and track days.",
                8, 16699, "cycle_yamaha_yzfr1.jpg"));

        addItem(new DataItem(null, "2018 YAMAHA YZ450FX", "Motorcycles",
                "Designed for closed course X-Country and enduro-type racing the YZ450FX combines light, nimble handling with the power of a 450.",
                9, 8999, "cycle_yamaha_yz450fx.jpg"));

        addItem(new DataItem(null, "2018 YAMAHA BOLT", "Motorcycles",
                "The Bolt features compact, raw bobber design and a powerful 942 cc V-Twin for a perfect union of old-school style and modern urban performance.",
                10, 7999, "cycle_yamaha_bolt.jpg"));

        addItem(new DataItem(null, "2017 YAMAHA FX CRUISER SVHO", "Watercraft",
                "HIGH PERFORMANCE WITH COMFORT AND STYLE",
                1, 15999, "water_yamaha_fx_cruiser_svho.jpg"));

        addItem(new DataItem(null, "2017 YAMAHA VXR", "Watercraft",
                "AGILE, POWERFUL, SERIOUSLY FUN",
                2, 11999, "water_yamaha_vxr.jpg"));

        addItem(new DataItem(null, "2017 YAMAHA VX LIMITED", "Watercraft",
                "ALL-INCLUSIVE FAMILY TUBING FUN MACHINE",
                3, 10999, "water_yamaha_vx_limited.jpg"));

        addItem(new DataItem(null, "2017 YAMAHA EX DELUXE", "Watercraft",
                "ENTRY LEVEL MEETS FEATURES AND HI-TECH",
                4, 8599, "water_yamaha_ex_deluxe.jpg"));
    }

    private static void addItem(DataItem item) {
        dataItemList.add(item);
        dataItemMap.put(item.getItemId(), item);
    }

}
